# Typescript REST API with Lowdb
A CRUD REST API with Swagger Docs and Lowdb as database

# Issues

- https://github.com/typicode/lowdb/issues/233
- https://github.com/Surnet/swagger-jsdoc/issues/249